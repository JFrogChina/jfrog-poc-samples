# Python Project Setup for Security Engineers

## Prerequisites
- macOS system
- Python 3.x installed
- Access to Artifactory instance

## 1. Set Up the Project
### Navigate to the project directory:
```sh
cd ./python
```

### Ensure `requirements.txt` file exists to manage dependencies:
```sh
ls requirements.txt
```

### Ensure project files, e.g., `main.py`, exist:
```sh
ls main.py
```

## 2. Set Up Artifactory for Dependency Management
### Configure pip to use Artifactory:
Create or edit the pip configuration file:

On macOS:
```sh
mkdir -p ~/.pip
vi ~/.pip/pip.conf
```

Add the following:
```ini
[global]
index-url = https://<USERNAME>:<PASSWORD>@<ARTIFACTORY_URL>/artifactory/api/pypi/<REPO_NAME>/simple
```
Replace `<USERNAME>`, `<PASSWORD>`, `<ARTIFACTORY_URL>`, and `<REPO_NAME>` with your Artifactory instance details.

## 3. Install Dependencies
### Add dependencies to `requirements.txt`, e.g.:
```
requests==2.25.1
```

### Install the dependencies:
```sh
pip install -r requirements.txt
```

## 4. Generate a Distribution Package
### If creating and uploading your own package:
Ensure `setup.py` file exists:
```sh
ls setup.py
```

Add the following to `setup.py` if not already present:
```python
from setuptools import setup, find_packages

setup(
    name='your_package_name',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'requests',
    ],
)
```

### Build the package:
```sh
python setup.py sdist
```

## 5. Upload Your Package to Artifactory
### Install `twine`:
```sh
pip install twine
```

### Upload the package:
```sh
twine upload --repository-url https://<ARTIFACTORY_URL>/artifactory/api/pypi/<REPO_NAME> dist/*
```
Replace `<ARTIFACTORY_URL>` and `<REPO_NAME>` with your Artifactory instance details.